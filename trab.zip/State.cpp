#include "State.hpp"
#include <iostream>
State::State(){
    bg = new Sprite("./ocean.jpg");
    music = new Music("./Recursos/audio/stageState.ogg");
    music ->Play();
    quitRequested = false;
}

void State::LoadAssets(){
    true;
}
void State::Render(){
    bg -> Render(0,0);
}
void State::Update(float dt){
    if(SDL_QuitRequested()){
        music ->Stop();
        quitRequested = true;
    }
}
bool State::QuitRequested(){
    return quitRequested;
}